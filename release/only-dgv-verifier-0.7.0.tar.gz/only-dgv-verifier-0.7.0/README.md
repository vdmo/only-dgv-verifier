# ONLY DGV verifier bundle

This package contains the DGV test-card suite for the v0.7.0 / 55-card standard together with the native release binaries for the verifier and cryptographic gate.

## Contents
- test_cards/: 55 JSON test cards for the current standard
- evidence/: generated evidence bundles and receipts
- versions/: historical registry snapshots
- binaries/dgv-verifier: native Rust verifier binary
- binaries/only-gate: native cryptographic validation binary

## Quick start
```bash
./binaries/dgv-verifier --help
./binaries/only-gate --check=signature --message=hello
```

## Notes
- The desktop and TUI assets were intentionally excluded from this bundle.
- The Python harness remains available in the package root for local inspection and replay.
